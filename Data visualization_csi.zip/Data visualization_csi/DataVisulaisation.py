#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load the Walmart dataset
walmart = pd.read_csv('A:\coding\python\Walmart.csv')

# Displaying dataset information
print("Dataset Overview:")
print(walmart.head())
print()
print("Dataset Information:")
print(walmart.info())

# Set seaborn style with color codes
sns.set(color_codes=True)

# Plotting weekly sales by store
plt.figure(figsize=(12, 6))
sns.barplot(x='Store', y='Weekly_Sales', data=walmart)
plt.title('Weekly Sales by Store')
plt.xlabel('Store')
plt.ylabel('Weekly Sales')
plt.show()

# Plotting weekly sales by store with holiday flag
plt.figure(figsize=(12, 6))
sns.barplot(x='Store', y='Weekly_Sales', hue='Holiday_Flag', data=walmart)
plt.title('Weekly Sales by Store with Holiday Flag')
plt.xlabel('Store')
plt.ylabel('Weekly Sales')
plt.legend(title='Holiday Flag')
plt.show()

# Pie chart of holiday flag distribution
plt.figure(figsize=(8, 8))
holiday_counts = walmart['Holiday_Flag'].value_counts()
plt.pie(holiday_counts, labels=['Non-Holiday', 'Holiday'], autopct='%1.1f%%', startangle=140)
plt.title('Distribution of Holiday Flag')
plt.axis('equal')
plt.show()

# Scatter plot of Temperature vs Weekly Sales with holiday flag
plt.figure(figsize=(10, 6))
sns.scatterplot(x='Temperature', y='Weekly_Sales', hue='Holiday_Flag', data=walmart)
plt.title('Temperature vs. Weekly Sales')
plt.xlabel('Temperature')
plt.ylabel('Weekly Sales')
plt.legend(title='Holiday')
plt.show()

# Histogram of CPI (Consumer Price Index)
plt.figure(figsize=(10, 6))
sns.histplot(walmart['CPI'], bins=20, kde=True)
plt.title('Distribution of CPI')
plt.xlabel('CPI')
plt.ylabel('Frequency')
plt.show()

# Scatter plot of Fuel Price vs Weekly Sales with holiday flag
plt.figure(figsize=(10, 6))
sns.scatterplot(x='Fuel_Price', y='Weekly_Sales', hue='Holiday_Flag', data=walmart)
plt.title('Fuel Price vs. Weekly Sales')
plt.xlabel('Fuel Price')
plt.ylabel('Weekly Sales')
plt.legend(title='Holiday Flag', loc='upper right')
plt.show()

# Scatter plot of Unemployment vs CPI (Consumer Price Index)
plt.figure(figsize=(10, 6))
sns.scatterplot(x='CPI', y='Unemployment', data=walmart)
plt.title('CPI vs. Unemployment')
plt.xlabel('CPI')
plt.ylabel('Unemployment')
plt.show()

# JointGrid visualization of Temperature vs Weekly Sales
sns.set_palette("muted")
g = sns.JointGrid(data=walmart, x='Temperature', y='Weekly_Sales')
g = g.plot(sns.scatterplot, sns.histplot)
plt.subplots_adjust(top=0.9)
g.fig.suptitle('JointGrid: Temperature vs. Weekly Sales')
plt.show()

# Boxplot of Weekly Sales distribution by Store
plt.figure(figsize=(10, 6))
sns.boxplot(x='Store', y='Weekly_Sales', data=walmart, palette='pastel')
plt.title('Weekly Sales Distribution by Store')
plt.xlabel('Store')
plt.ylabel('Weekly Sales')
plt.show()

# Point plot of Weekly Sales vs Holiday Flags
plt.figure(figsize=(10, 6))
sns.pointplot(x='Holiday_Flag', y='Weekly_Sales', data=walmart, palette='colorblind')
plt.title('Weekly Sales vs Holiday Flags')
plt.xlabel('Holiday Flag')
plt.ylabel('Weekly Sales')
plt.xticks([0, 1], ['Non-Holiday', 'Holiday'])
plt.show()

# Point plot of Temperature vs Weekly Sales
plt.figure(figsize=(10, 6))
sns.pointplot(x='Temperature', y='Weekly_Sales', data=walmart, palette='deep')
plt.title('Temperature vs Weekly Sales')
plt.xlabel('Temperature')
plt.ylabel('Weekly Sales')
plt.show()


# In[ ]:




